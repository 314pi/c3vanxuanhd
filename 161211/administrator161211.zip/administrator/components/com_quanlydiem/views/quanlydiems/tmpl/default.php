<?php defined('_JEXEC') or die('Restricted access'); ?>
<form action="index.php" method="post" name="adminForm">
<table class="adminform">
	<tr>
		<td width="55%" valign="top">
			<div id="cpanel">

	<tr> <h1 align = "center"> Chào mừng bạn đến với Component quản lý điểm!</h1></tr>
	<tr><h2 align = "center"> Cám ơn bạn đã sử dụng Component quản lý điểm!</h2> </tr>
	<tr> <h3 align = "center"> Mọi thắc mắc xin liên hệ:</h3> </tr>
	<tr> <h2 align = "center"> LÊ VIỆT HÙNG</h2></tr>
	<tr> <h3 align = "center"> Điện thoại: 01696 144 148</h3></tr>
	<tr> <h3 align = "center"> Email: hungtinly11@gmail.com</h3></tr>
</table>
</div>

<input type="hidden" name="option" value="com_quanlydiem" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="controller" value="quanlydiem" />
</form>
