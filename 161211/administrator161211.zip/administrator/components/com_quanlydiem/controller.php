<?php
jimport('joomla.application.component.controller');
class QuanlydiemsController extends JController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display()
	{
		parent::display();
	}

}
?>
