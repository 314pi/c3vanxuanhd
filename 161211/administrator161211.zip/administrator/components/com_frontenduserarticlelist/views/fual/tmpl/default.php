<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

?>
<span style="font-weight:bold;">
	<?php echo JText::_('FUAL_WELCOME'); ?>
</span>
<br /><br />
<?php echo JText::_('FUAL_MESSAGE'); ?>